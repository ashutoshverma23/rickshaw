import mongoose from "mongoose";

const driverSchema = new mongoose.Schema({
    fullName: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    },
    licensePlate: {
        type: String,
        required: true
    },
    isVerified: {
        type: Boolean,
        default: false
    },
    verificationToken: {
        type: String
    },
    drivingLicenseImagePath: {
        type: String
    },
},
    {
        timestamps: true
    }
);

const Driver = mongoose.model('Driver', driverSchema)
export default Driver